$(document).ready(function(){
  centerContent();
  $(window).resize(centerContent);
  
});

function centerContent(){
  
  if ($(window).width() <= 635) {
    $("footer div").first().addClass("text-center");
    $("nav#bottomnav").addClass("text-center");
    $("div#contact").removeClass("text-right");
    $("div#contact").css({"float": "none"});
  }
  else {
   $("footer div").first().removeClass("text-center"); 
   $("nav#bottomnav").removeClass("text-center");
   $("div#contact").addClass("text-right");
   $("div#contact").css({"float": "right"});
   
  }
};